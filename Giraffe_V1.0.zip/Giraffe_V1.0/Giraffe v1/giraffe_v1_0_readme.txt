Giraffe V1.0 (3ds Max, Rhino & Revit)
Extract your version's ZIP and run Giraffe_V1_Setup.exe